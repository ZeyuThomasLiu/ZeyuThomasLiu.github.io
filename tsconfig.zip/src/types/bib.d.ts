declare module '*.bib' {
  const content: string;
  export default content;
} 