I am a PhD student at the School of Science, University of Example, advised by [Prof. Advisor One](https://example.com) and [Dr. Advisor Two](https://example.com).

Prior to this, I obtained a BSc degree with First Class Honours in Natural Science from the University of Example.

My current research focuses on investigating the mathematical principles of natural philosophy.