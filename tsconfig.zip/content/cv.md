## Education

**The University of Example**, PhD in Natural Science, *2025 - Present*
- Research focus: Mathematical Principles of Natural Philosophy
- Supervisor: Prof. Advisor One and Dr. Advisor Two

**The University of Example**, BSc in Natural Science, *2021 - 2025*
- Graduated with First Class Honours

## Experience

**Example Role**
Company/Institution
*2023 - 2024*
- Description of key responsibilities and achievements.
- Utilized skills to solve problems.

## Skills

- **Programming:** Python, C++, MATLAB, LaTeX
- **Data Analysis:** Pandas, NumPy, SciPy
- **Languages:** English (Native), French (Fluent)

## Awards & Honors

- **First Prize in Example Competition** - Committee of Example (*2024*)
